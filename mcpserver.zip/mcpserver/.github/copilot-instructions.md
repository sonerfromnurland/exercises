<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is an MCP server project for analyzing credit card transactions and answering user questions via AI.

You can find more info and examples at https://modelcontextprotocol.io/llms-full.txt
SDK reference: https://github.com/modelcontextprotocol/create-python-server
