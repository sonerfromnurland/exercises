﻿namespace Contracts;

public class Class1
{
}