﻿namespace LoggerService;

public class Class1
{
}